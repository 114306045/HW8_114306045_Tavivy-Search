package com.example.boogle.controller;

import com.example.boogle.model.SearchResult;
import com.example.boogle.service.TavilySearchService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class SearchController {

    private final TavilySearchService searchService;

    public SearchController(TavilySearchService searchService) {
        this.searchService = searchService;
    }

    @GetMapping("/")
    public String index(
            @RequestParam(name = "q", required = false, defaultValue = "") String query,
            Model model) {

        String cleanQuery = query.trim();
        model.addAttribute("query", cleanQuery);
        model.addAttribute("searched", !cleanQuery.isBlank());

        if (cleanQuery.isBlank()) {
            model.addAttribute("results", List.of());
            return "index";
        }

        try {
            List<SearchResult> results = searchService.search(cleanQuery);
            model.addAttribute("results", results);
            model.addAttribute("message",
                    results.isEmpty() ? "沒有找到結果，試試其他關鍵字吧！" : "");
        } catch (IllegalStateException ex) {
            model.addAttribute("results", List.of());
            model.addAttribute("message", ex.getMessage());
        }

        return "index";
    }
}
