package com.example.boogle.model;

public record SearchResult(String title, String url, String content) {
}
