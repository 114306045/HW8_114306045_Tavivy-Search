package com.example.boogle.service;

import com.example.boogle.model.SearchResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.List;
import java.util.Map;

@Service
public class TavilySearchService {

    private final boolean enabled;
    private final String apiKey;
    private final RestClient restClient;

    public TavilySearchService(
            @Value("${tavily.enabled:false}") boolean enabled,
            @Value("${tavily.api-key:}") String apiKey,
            RestClient.Builder restClientBuilder) {
        this.enabled = enabled;
        this.apiKey = apiKey;
        this.restClient = restClientBuilder
                .baseUrl("https://api.tavily.com")
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build();
    }

    @SuppressWarnings("unchecked")
    public List<SearchResult> search(String query) {
        if (!enabled) {
            throw new IllegalStateException("搜尋服務尚未啟用，請設定 TAVILY_ENABLED=true。");
        }
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException("找不到 Tavily API Key，請設定環境變數 TAVILY_API_KEY。");
        }

        Map<String, Object> requestBody = Map.of(
                "query", query,
                "max_results", 10,
                "search_depth", "basic",
                "include_answer", false
        );

        try {
            Map<String, Object> response = restClient.post()
                    .uri("/search")
                    .headers(headers -> headers.setBearerAuth(apiKey))
                    .body(requestBody)
                    .retrieve()
                    .body(Map.class);

            if (response == null || !(response.get("results") instanceof List<?> items)) {
                return List.of();
            }

            return items.stream()
                    .filter(Map.class::isInstance)
                    .map(item -> (Map<String, Object>) item)
                    .map(item -> new SearchResult(
                            asText(item.get("title")),
                            asText(item.get("url")),
                            asText(item.get("content"))))
                    .filter(item -> !item.title().isBlank() && !item.url().isBlank())
                    .toList();
        } catch (RestClientException ex) {
            throw new IllegalStateException(
                    "目前無法連線到 Tavily Search API，請確認網路與 API Key 是否正確。", ex);
        }
    }

    private String asText(Object value) {
        return value == null ? "" : value.toString();
    }
}
