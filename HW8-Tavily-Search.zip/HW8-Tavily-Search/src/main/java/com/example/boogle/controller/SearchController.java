package com.example.boogle.controller;

import com.example.boogle.model.SearchResult;
import com.example.boogle.service.TavilySearchService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
public class SearchController {

    private final TavilySearchService searchService;

    public SearchController(TavilySearchService searchService) {
        this.searchService = searchService;
    }

    @GetMapping("/api/search")
    public ResponseEntity<?> search(@RequestParam(name = "q", defaultValue = "") String query) {
        String cleanedQuery = query.trim();
        if (cleanedQuery.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "請先輸入想搜尋的關鍵字。"));
        }
        if (cleanedQuery.length() > 200) {
            return ResponseEntity.badRequest().body(Map.of("message", "搜尋字詞請控制在 200 個字以內。"));
        }

        try {
            List<SearchResult> results = searchService.search(cleanedQuery);
            return ResponseEntity.ok(Map.of(
                    "query", cleanedQuery,
                    "results", results,
                    "count", results.size()
            ));
        } catch (IllegalStateException ex) {
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                    .body(Map.of("message", ex.getMessage()));
        }
    }
}
