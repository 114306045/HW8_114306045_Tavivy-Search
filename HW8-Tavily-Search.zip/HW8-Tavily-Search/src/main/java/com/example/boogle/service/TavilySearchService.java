package com.example.boogle.service;

import com.example.boogle.model.SearchResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class TavilySearchService {

    @Value("${tavily.enabled:true}")
    private boolean enabled;

    @Value("${tavily.apiKey:}")
    private String apiKey;

    private final RestTemplate restTemplate = new RestTemplate();

    @SuppressWarnings("unchecked")
    public List<SearchResult> search(String query) {
        if (!enabled) {
            throw new IllegalStateException("搜尋功能目前尚未啟用，請檢查設定。");
        }
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException("尚未設定 Tavily API Key。請依 README 設定 TAVILY_API_KEY 環境變數。");
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("query", query);
        body.put("max_results", 10);
        body.put("search_depth", "basic");

        try {
            Map<String, Object> response = restTemplate.postForObject(
                    "https://api.tavily.com/search",
                    new HttpEntity<>(body, headers),
                    Map.class
            );

            List<SearchResult> results = new ArrayList<>();
            if (response == null || !(response.get("results") instanceof List<?> items)) {
                return results;
            }

            for (Object itemObject : items) {
                if (!(itemObject instanceof Map<?, ?> item)) continue;
                Object title = item.get("title");
                Object url = item.get("url");
                Object content = item.get("content");

                if (title != null && url != null) {
                    results.add(new SearchResult(
                            title.toString(),
                            url.toString(),
                            content == null ? "" : content.toString()
                    ));
                }
            }
            return results;
        } catch (RestClientResponseException ex) {
            throw new IllegalStateException(
                    "Tavily API 回應錯誤（HTTP " + ex.getStatusCode().value() +
                    "）。請確認 API Key 與 Tavily 額度。"
            );
        } catch (Exception ex) {
            if (ex instanceof IllegalStateException illegalStateException) {
                throw illegalStateException;
            }
            throw new IllegalStateException("目前無法連線到搜尋服務，請稍後再試。");
        }
    }
}
