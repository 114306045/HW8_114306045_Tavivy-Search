const form = document.getElementById("search-form");
const input = document.getElementById("query");
const clearButton = document.getElementById("clear-button");
const resultsSection = document.getElementById("results-section");
const resultsTitle = document.getElementById("results-title");
const resultCount = document.getElementById("result-count");
const resultsList = document.getElementById("results-list");
const statusBox = document.getElementById("status");
const searchButton = form.querySelector("button[type='submit']");

clearButton.addEventListener("click", () => {
    input.value = "";
    input.focus();
});

function showStatus(message, isError = false) {
    statusBox.textContent = message;
    statusBox.className = isError ? "status error" : "status";
}

function makeResultCard(item) {
    const article = document.createElement("article");
    article.className = "result-card";

    const heading = document.createElement("h3");
    const link = document.createElement("a");
    link.href = item.url;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = item.title || item.url;
    heading.appendChild(link);

    const url = document.createElement("a");
    url.className = "result-url";
    url.href = item.url;
    url.target = "_blank";
    url.rel = "noopener noreferrer";
    url.textContent = item.url;

    const description = document.createElement("p");
    description.textContent = item.content || "這筆搜尋結果沒有提供摘要。";

    article.append(heading, url, description);
    return article;
}

form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const query = input.value.trim();
    if (!query) {
        resultsSection.hidden = false;
        resultsList.replaceChildren();
        resultCount.textContent = "";
        showStatus("請先輸入想搜尋的關鍵字。", true);
        input.focus();
        return;
    }

    resultsSection.hidden = false;
    resultsTitle.textContent = `「${query}」的搜尋結果`;
    resultCount.textContent = "";
    resultsList.replaceChildren();
    showStatus("正在搜尋網路資料，請稍候...");
    searchButton.disabled = true;
    searchButton.textContent = "搜尋中…";

    try {
        const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || "搜尋服務暫時無法使用，請稍後再試。");
        }

        const results = Array.isArray(data.results) ? data.results : [];
        resultCount.textContent = `找到 ${results.length} 筆結果`;
        statusBox.textContent = "";

        if (results.length === 0) {
            resultsList.innerHTML = '<div class="empty-state"><strong>沒有找到結果</strong>試試不同的關鍵字，或簡化搜尋條件。</div>';
            return;
        }
        results.forEach(item => resultsList.appendChild(makeResultCard(item)));
    } catch (error) {
        resultsList.replaceChildren();
        showStatus(error.message || "發生未知錯誤，請稍後再試。", true);
    } finally {
        searchButton.disabled = false;
        searchButton.textContent = "搜尋";
    }
});
